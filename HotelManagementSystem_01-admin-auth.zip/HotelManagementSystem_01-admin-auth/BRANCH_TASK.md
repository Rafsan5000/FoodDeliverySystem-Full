# GitHub Branch Package — Member 1 — Admin & Authentication

**Suggested branch name:** `admin-management`

This ZIP is a complete snapshot of the current working project so Visual Studio can open/build it normally. All four members start from the same base project; each member should commit changes mainly to the files listed below, then push this work to the suggested branch.

## Assigned files
- `Controller/AdminController.cs`
- `Controller/LogInController.cs`
- `Model/Admin.cs`
- `Model/Admins.cs`
- `Model/LogIn.cs`
- `Model/LogIns.cs`
- `View/AdminCustomers.cs`
- `View/AdminCustomers.Designer.cs`
- `View/AdminCustomers.resx`
- `View/AdminDashBoard.cs`
- `View/AdminDashBoard.Designer.cs`
- `View/AdminDashBoard.resx`
- `View/AdminEmployees.cs`
- `View/AdminEmployees.Designer.cs`
- `View/AdminEmployees.resx`
- `View/AdminLogIn.cs`
- `View/AdminLogIn.Designer.cs`
- `View/AdminLogIn.resx`
- `View/SuperAdminManager.cs`
- `View/LogInForm.cs`
- `View/LogInForm.Designer.cs`
- `View/LogInForm.resx`

## Shared files
These remain available in every branch because the project must stay buildable:
- `App.config`
- `Program.cs`
- `FoodDeliverySystem.csproj`
- `FoodDeliverySystem.sln`
- `README.md`
- `Properties/AssemblyInfo.cs`
- `Properties/Resources.Designer.cs`
- `Properties/Resources.resx`
- `Properties/Settings.Designer.cs`
- `Properties/Settings.settings`
- `Pictures/` (shared image assets)

## GitHub workflow
1. Create/use the suggested branch from `main`.
2. Upload the contents of this project folder.
3. Make changes for this member's assigned module.
4. Commit with a meaningful message.
5. Push the branch and open a Pull Request into `main`.

**Important:** Do not delete the common files just to make the branches smaller. These packages are intentionally full project snapshots so each branch can be opened and tested independently.
