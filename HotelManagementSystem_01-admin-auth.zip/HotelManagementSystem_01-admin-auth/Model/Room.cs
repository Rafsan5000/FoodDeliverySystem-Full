namespace FoodDeliverySystem.Model
{
    public class Room
    {
        public string RoomId { get; set; }
        public string HotelId { get; set; }
        public string HotelName { get; set; }
        public string RoomNumber { get; set; }
        public string RoomType { get; set; }
        public int Capacity { get; set; }
        public decimal PricePerNight { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public string Status { get; set; }
    }
}
