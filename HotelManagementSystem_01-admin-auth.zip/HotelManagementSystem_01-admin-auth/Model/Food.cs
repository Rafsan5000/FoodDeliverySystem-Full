﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliverySystem.Model
{
    public class Food
    {
        private string foodId;
        private string foodName;
        private float quantity;
        private float price;
        private string description;
        private string id;
        private byte[] image;

        public Food()
        {

        }

        public Food(string foodId, string foodName, float quantity, float price, string description, string  id, byte[] image)
        {
            this.FoodId = foodId;
            this.FoodName = foodName;
            this.Quantity = quantity;
            this.Price = price;
            this.Description = description;
            this.Id = id;
            this.Image = image;
        }

        public string FoodId { get => foodId; set => foodId = value; }
        public string FoodName { get => foodName; set => foodName = value; }
        public float Quantity { get => quantity; set => quantity = value; }
        public float Price { get => price; set => price = value; }
        public string Description { get => description; set => description = value; }
        public string Id { get => id; set => id = value; }
        public byte[] Image { get => image; set => image = value; }
    }
}
