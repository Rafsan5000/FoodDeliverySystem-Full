﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Remoting;

namespace FoodDeliverySystem.Model
{
    public class Orders
    {
        public SqlDbDataAccess sda = new SqlDbDataAccess();

        public void AddOrder(Order order)
        {
            SqlCommand cmd = sda.GetQuery(
                "INSERT INTO Orders (OrderId, CustomerId, TotalPrice, Date, ProductNames,Address,PaymentMethod, PaymentStatus) " +
                "VALUES (@OrderId, @CustomerId,@TotalPrice, @OrderDate, @ProductNames,@Address, @PaymentMethod, @PaymentStatus);");

            cmd.Parameters.AddWithValue("@OrderId", order.OrderId);
            cmd.Parameters.AddWithValue("@CustomerId", order.CustomerId);
            cmd.Parameters.AddWithValue("@TotalPrice", order.TotalPrice);
            cmd.Parameters.AddWithValue("@OrderDate", order.Date);
            cmd.Parameters.AddWithValue("@ProductNames", order.ProductsName);
            cmd.Parameters.AddWithValue("@Address", order.Address);
            cmd.Parameters.AddWithValue("@PaymentMethod", order.PaymentMethod);
            cmd.Parameters.AddWithValue("@PaymentStatus", order.PaymentStatus);


            cmd.CommandType = CommandType.Text;

            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Connection.Close();
            }
        }

        public int GetOrderCount()
        {
            SqlCommand cmd = sda.GetQuery("SELECT COUNT(*) FROM Orders");
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            return count;
        }

        public string GetLatestOrderProductNames()
        {
            SqlCommand cmd = sda.GetQuery("SELECT TOP 1 ProductNames FROM Orders ORDER BY Date DESC, OrderId DESC");
            cmd.Connection.Open();
            object result = cmd.ExecuteScalar();
            cmd.Connection.Close();

            return result?.ToString() ?? string.Empty;
        }


        public double GetLatestTotalPrice()
        {
            SqlCommand cmd = sda.GetQuery("SELECT TOP 1 TotalPrice FROM Orders ORDER BY Date DESC, OrderId DESC");
            cmd.Connection.Open();
            object result = cmd.ExecuteScalar();
            cmd.Connection.Close();

            if (result != null && double.TryParse(result.ToString(), out double parsed))
                return parsed;

            return 0;
        }


        public void UpdateOrderAddress(Order order)
        {
            SqlCommand cmd = sda.GetQuery("UPDATE Orders SET Address = @Address, PaymentMethod = @PaymentMethod WHERE OrderId = @OrderId;");
            cmd.Parameters.AddWithValue("@OrderId", order.OrderId);
            cmd.Parameters.AddWithValue("@Address", order.Address);
            cmd.Parameters.AddWithValue("@PaymentMethod", order.PaymentMethod);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

        public List<Order> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Order> orderList = new List<Order>();

            using (reader)
            {
                while (reader.Read())
                {
                    Order o = new Order();
                    o.OrderId = reader.GetString(0);
                    o.CustomerId = reader.GetString(1);
                    o.TotalPrice = reader.GetDouble(2);
                    o.Date = reader.GetDateTime(3);
                    o.ProductsName = reader.GetString(4);
                    o.Address = reader.GetString(5);
                    o.PaymentMethod = reader.GetString(6);
                    o.PaymentStatus = reader.GetString(7);

                    orderList.Add(o);
                }

                reader.Close();
            }

            cmd.Connection.Close();
            return orderList;
        }

        public List<Order> GetAllOrders()
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Orders;");
            cmd.CommandType = CommandType.Text;
            List<Order> orderList = GetData(cmd);

            return orderList;
        }

        public List<Order> GetCustomerOrder(string customerId)
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Orders WHERE CustomerId=@CustomerId;");
            cmd.Parameters.AddWithValue("@CustomerId", customerId);

            cmd.CommandType = CommandType.Text;
            List<Order> orderList = GetData(cmd);

            return orderList;
        }

        public Order SearchOrder(string orderId)
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Orders WHERE OrderId = @OrderId;");
            cmd.Parameters.AddWithValue("@OrderId", orderId);
            cmd.CommandType = CommandType.Text;
            cmd.CommandType = CommandType.Text;

            List<Order> orderList = GetData(cmd);

            if (orderList.Count > 0)
            {
                return orderList[0];
            }

            else
            {
                return null;
            }
        }


        public void UpdateOrderStatus(Order order)
        {
            SqlCommand cmd = sda.GetQuery("UPDATE Orders SET PaymentStatus = @PaymentStatus WHERE OrderId = @OrderId;");
            cmd.Parameters.AddWithValue("@OrderId", order.OrderId);
            cmd.Parameters.AddWithValue("@PaymentStatus", order.PaymentStatus);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

        public void DeleteOrder(string orderId)
        {
            SqlCommand cmd = sda.GetQuery("DELETE FROM Orders WHERE OrderId = @OrderId");
            cmd.Parameters.AddWithValue("@OrderId", orderId);
            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

    }
}
