using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;


namespace FoodDeliverySystem.Model
{
    public class Foods
    {
        SqlDbDataAccess sda = new SqlDbDataAccess();

        public void AddFood(Food food)
        {
            SqlCommand cmd = sda.GetQuery("INSERT INTO Food VALUES(@FoodId,@FoodName,@Quantity,@Price,@Description,@Id,@Image);");

            cmd.Parameters.AddWithValue("@FoodId", food.FoodId);
            cmd.Parameters.AddWithValue("@FoodName", food.FoodName);
            cmd.Parameters.AddWithValue("@Quantity", food.Quantity);
            cmd.Parameters.AddWithValue("@Price", food.Price);
            cmd.Parameters.AddWithValue("@Description", food.Description);
            cmd.Parameters.AddWithValue("@Id", food.Id);
            cmd.Parameters.Add("@Image", SqlDbType.VarBinary).Value = food.Image;

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

        public void DeleteFood(string foodId)
        {
            SqlCommand cmd = sda.GetQuery("DELETE From Food WHERE foodId=@FoodId;");
            cmd.Parameters.AddWithValue("@FoodId", foodId);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();

        }

        public void DeleteFoodId(string Id)
        {
            SqlCommand cmd = sda.GetQuery("DELETE From Food WHERE id=@Id;");
            cmd.Parameters.AddWithValue("@Id", Id);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }

        public List<Food> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Food> foodList = new List<Food>();

            using (reader)
            {
                while (reader.Read())
                {
                    Food food = new Food();
                    food.FoodId = reader.GetString(0);
                    food.FoodName = reader.GetString(1);
                    food.Quantity = Convert.ToSingle(reader[2]);      
                    food.Price = Convert.ToSingle(reader[3]);
                    food.Description = reader.GetString(4);
                    food.Id = reader.GetString(5);
                    byte[] dbImage = reader["Image"] == DBNull.Value ? null : (byte[])reader["Image"];
                    food.Image = (dbImage != null && dbImage.Length > 0) ? dbImage : DefaultImageBytes();

                    foodList.Add(food);
                }

                reader.Close();
            }

            cmd.Connection.Close();
            return foodList;
        }

        private byte[] DefaultImageBytes()
        {
            using (MemoryStream ms = new MemoryStream())
            {
                Properties.Resources._default.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        public List<Food> GetAllFood()
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Food;");
            cmd.CommandType = CommandType.Text;

            List<Food> foodList = GetData(cmd);

            return foodList;
        }

        public Food SearchFood(string foodId)
        {
            SqlCommand cmd = sda.GetQuery("SELECT * FROM Food WHERE foodId=@FoodId;");
            cmd.Parameters.AddWithValue("@FoodId", foodId);

            List<Food> foodList = GetData(cmd);

            if (foodList.Count > 0)
            {
                return foodList[0];
            }

            else
            {
                return null;
            }
        }


        public void UpdateFood(Food food)
        {
            SqlCommand cmd = sda.GetQuery("UPDATE Food SET  foodName=@FoodName, quantity=@Quantity, price=@Price, description=@Description,  id=@Id, image=@Image WHERE foodId=@FoodId;");
            cmd.Parameters.AddWithValue("@FoodId", food.FoodId);
            cmd.Parameters.AddWithValue("@FoodName", food.FoodName);
            cmd.Parameters.AddWithValue("@Quantity", food.Quantity);
            cmd.Parameters.AddWithValue("@Price", food.Price);
            cmd.Parameters.AddWithValue("@Description", food.Description);
            cmd.Parameters.AddWithValue("@Id", food.Id);
            cmd.Parameters.Add("@Image", SqlDbType.VarBinary).Value = food.Image;

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();

        }

        public bool UniqueFoodId(string foodId)
        {
            SqlCommand cmd = sda.GetQuery("SELECT FoodId FROM Food WHERE FoodId = @FoodId;");
            cmd.Parameters.AddWithValue("@FoodId", foodId);

            cmd.CommandType = CommandType.Text;
            cmd.Connection.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            bool exists = reader.HasRows;  
            reader.Close();
            cmd.Connection.Close();

            return exists;
        }

        //


        public bool DecreaseFoodQuantity(string foodId, int quantityToDecrease)
        {
            SqlCommand cmd = sda.GetQuery( "UPDATE Food SET Quantity = Quantity - @Qty WHERE FoodId = @FoodId AND Quantity >= @Qty;");

            cmd.Parameters.AddWithValue("@FoodId", foodId);
            cmd.Parameters.AddWithValue("@Qty", quantityToDecrease);

            cmd.Connection.Open();
            int rowsAffected = cmd.ExecuteNonQuery();
            cmd.Connection.Close();

            return rowsAffected > 0; 
        }

        public int GetEmployeeCount()
        { 
            SqlCommand cmd = sda.GetQuery("SELECT COUNT(*) FROM Employee");
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            return count;
        }
        public int GetFoodCount()
        {
            SqlCommand cmd = sda.GetQuery("SELECT COUNT(*) FROM Food");
            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            return count;
        }






    }
}
