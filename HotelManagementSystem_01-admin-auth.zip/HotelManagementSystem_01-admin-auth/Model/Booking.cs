using System;
namespace FoodDeliverySystem.Model
{
    public class Booking
    {
        public string BookingId { get; set; }
        public string CustomerId { get; set; }
        public string GuestName { get; set; }
        public string RoomId { get; set; }
        public string RoomNumber { get; set; }
        public string HotelId { get; set; }
        public string HotelName { get; set; }
        public string Location { get; set; }
        public string RoomType { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public int Guests { get; set; }
        public decimal TotalAmount { get; set; }
        public string BookingStatus { get; set; }
        public string PaymentStatus { get; set; }
        public DateTime BookingDate { get; set; }
    }
}
