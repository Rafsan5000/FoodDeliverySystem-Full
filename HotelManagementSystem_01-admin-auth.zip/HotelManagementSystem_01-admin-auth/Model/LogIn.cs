﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliverySystem.Model
{
    public class LogIn
    {
        private string logId;
        private string password;
        private string security;
        private string role;

        public LogIn()
        {

        }
        public LogIn(string logId, string password, string security, string role)
        {
            this.LogId = logId;
            this.Password = password;
            this.Security = security;
            this.Role = role;
        }

        public string LogId { get => logId; set => logId = value; }
        public string Password { get => password; set => password = value; }
        public string Security { get => security; set => security = value; }
        public string Role { get => role; set => role = value; }
    }
}
