﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FoodDeliverySystem.Model;
using FoodDeliverySystem.Controller;

namespace FoodDeliverySystem.Controller
{
    public class AdminController
    {
        public Admin SearchAdmin(string adminId, string password)
        {
            Admins ad= new Admins();
            Admin admin= ad.SearchAdmin(adminId, password);
            return admin;
        }
    }
}
