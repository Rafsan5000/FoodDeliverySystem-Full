﻿using FoodDeliverySystem.Model;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace FoodDeliverySystem.Controller
{
    public class OrderController
    {
        public Orders orders;

        public OrderController()
        {
            orders = new Orders();
        }
        public string GetLatestOrderId()
        {
            SqlCommand cmd = orders.sda.GetQuery("SELECT TOP 1 OrderId FROM Orders ORDER BY Date DESC, OrderId DESC");
            cmd.Connection.Open();
            object result = cmd.ExecuteScalar();
            cmd.Connection.Close();
            return result?.ToString() ?? string.Empty;
        }

        public void AddOrder(Order order) => orders.AddOrder(order);
        public int GetOrderCount() => orders.GetOrderCount();
        public string GetLatestOrderProductNames() => orders.GetLatestOrderProductNames();
        public double GetLatestOrderTotalPrice() => orders.GetLatestTotalPrice();


        public void UpdateOrderAddress(Order oo)
        {
            Orders orders = new Orders();
            orders.UpdateOrderAddress(oo);
        }

        public Order SearchOrder(string orderId)
        {
            Orders cs = new Orders();
            Order cc = cs.SearchOrder(orderId);
            return cc;
        }

        public List<Order> GetAllOrders()
        {
            Orders em = new Orders();
            List<Order> orderList = em.GetAllOrders();
            return orderList;
        }

        public List<Order> GetCustomerOrder(string customerId)
        {
            Orders em = new Orders();
            List<Order> orderList = em.GetCustomerOrder(customerId);
          

            return orderList;
        }


        public void UpdateOrderStatus(Order oo)
        {
            Orders od = new Orders();
            od.UpdateOrderStatus(oo);
        }

        public void DeleteOrder(string orderId)
        {
            Orders od = new Orders();
            od.DeleteOrder(orderId);
        }

        public int ShowTotalOrders()
        {
            OrderController oc = new OrderController();
            return oc.GetOrderCount();
        }
    }
}
