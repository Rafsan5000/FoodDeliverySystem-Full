using System.Collections.Generic;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class EmployeeController
    {
        private readonly Employees employeeService = new Employees();

        public void AddEmployee(Employee employee) { employeeService.AddEmployee(employee); }
        public void UpdateByAmdin(Employee employee) { employeeService.UpdateByAdmin(employee); }
        public void DeleteEmployee(string employeeId) { employeeService.DeleteEmployee(employeeId); }
        public Employee SearchEmployee(string employeeId) { return employeeService.SearchEmployee(employeeId); }
        public List<Employee> GetAllEmployee() { return employeeService.GetAllEmployee(); }
        public int ShowTotalEmployees() { return employeeService.GetEmployeeCount(); }
        public int GetEmployeeCount() { return employeeService.GetEmployeeCount(); }
        public string GenerateNewEmployeeId() { return employeeService.GenerateNewEmployeeId(); }
    }
}
