﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class CustomerController
    {
        private Customers customerService = new Customers();

        public void AddCustomer(Customer customer)
        {
            Customers c = new Customers();
            c.AddCustomer(customer);
        }


        public Customer SearchCustomer(string customerId)
        {
            Customers cs = new Customers();
            Customer cc= cs.SearchCustomer(customerId);
            return cc;
        }

        public void UpdateByAdmin(Customer c)
        {
            Customers cs = new Customers();
            cs.UpdateByAdmin(c);
        }

        public void UpdateCustomer(Customer c)
        {
            Customers cs = new Customers();
            cs.UpdateCustomer(c);
        }

        public List<Customer> GetAllCustomer()
        {
            Customers cc = new Customers();
            List<Customer> customerList = cc.GetAllCustomer();
            return customerList;
        }

        public void DeleteCustomer(string customerId)
        {
            Customers cs = new Customers();
            cs.DeleteCustomer(customerId);
        }

        public int GetCustomerCount()
        {
            return customerService.GetCustomerCount();
        }

        public int ShowTotalCustomers()
        {
            CustomerController cc = new CustomerController();
            return cc.GetCustomerCount();
        }


        public string GenerateNewCustomerId()
        {
            int count = GetCustomerCount() + 1;
            return "C-" + count.ToString("D4");
        }
    }
}
