using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.Controller
{
    public class BookingController
    {
        private const string Summary = @"
            SELECT BookingId,CustomerId,GuestName,RoomId,RoomNumber,HotelId,HotelName,
                   Location,RoomType,CheckInDate,CheckOutDate,Guests,TotalAmount,
                   BookingStatus,PaymentStatus,BookingDate
            FROM dbo.vw_BookingSummary";

        public List<Booking> GetCustomerBookings(string customerId)
        {
            return Query(Summary + " WHERE CustomerId=@cid ORDER BY BookingDate DESC", customerId);
        }

        public List<Booking> GetAllBookings()
        {
            return Query(Summary + " ORDER BY BookingDate DESC", null);
        }

        public string CreateBooking(string customerId, string roomId, DateTime checkIn,
                                    DateTime checkOut, int guests)
        {
            checkIn = checkIn.Date;
            checkOut = checkOut.Date;

            if (checkOut <= checkIn)
                throw new Exception("Check-out date must be after check-in date.");
            if (guests <= 0)
                throw new Exception("Number of guests must be at least 1.");

            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            {
                cn.Open();
                using (SqlTransaction tx = cn.BeginTransaction(IsolationLevel.Serializable))
                {
                    try
                    {
                        decimal price;
                        int capacity;
                        string status;

                        using (SqlCommand cmd = new SqlCommand(@"
                            SELECT PricePerNight,Capacity,Status
                            FROM dbo.Rooms WITH (UPDLOCK,HOLDLOCK)
                            WHERE RoomId=@RoomId;", cn, tx))
                        {
                            cmd.Parameters.Add("@RoomId", SqlDbType.VarChar, 50).Value = roomId;
                            using (SqlDataReader r = cmd.ExecuteReader())
                            {
                                if (!r.Read())
                                    throw new Exception("Selected room was not found.");
                                price = r.GetDecimal(0);
                                capacity = r.GetInt32(1);
                                status = r.GetString(2);
                            }
                        }

                        if (!string.Equals(status, "Available", StringComparison.OrdinalIgnoreCase))
                            throw new Exception("Selected room is not currently available.");
                        if (guests > capacity)
                            throw new Exception("This room can accommodate only " + capacity + " guest(s).");

                        using (SqlCommand overlap = new SqlCommand(@"
                            SELECT COUNT(*) FROM dbo.Bookings
                            WHERE RoomId=@RoomId
                              AND BookingStatus IN ('Booked','Checked-In')
                              AND CheckInDate < @CheckOutDate
                              AND CheckOutDate > @CheckInDate;", cn, tx))
                        {
                            overlap.Parameters.Add("@RoomId", SqlDbType.VarChar, 50).Value = roomId;
                            overlap.Parameters.Add("@CheckInDate", SqlDbType.Date).Value = checkIn;
                            overlap.Parameters.Add("@CheckOutDate", SqlDbType.Date).Value = checkOut;
                            if (Convert.ToInt32(overlap.ExecuteScalar()) > 0)
                                throw new Exception("This room already has a booking for the selected dates.");
                        }

                        int nights = (checkOut - checkIn).Days;
                        decimal total = price * nights;
                        string bookingId = CreateBookingId(cn, tx);

                        using (SqlCommand cmd = new SqlCommand(@"
                            INSERT INTO dbo.Bookings
                                (BookingId,CustomerId,RoomId,CheckInDate,CheckOutDate,Guests,TotalAmount)
                            VALUES(@BookingId,@CustomerId,@RoomId,@CheckInDate,@CheckOutDate,@Guests,@Total);
                            UPDATE dbo.Rooms SET Status='Booked' WHERE RoomId=@RoomId;", cn, tx))
                        {
                            cmd.Parameters.Add("@BookingId", SqlDbType.VarChar, 50).Value = bookingId;
                            cmd.Parameters.Add("@CustomerId", SqlDbType.VarChar, 50).Value = customerId;
                            cmd.Parameters.Add("@RoomId", SqlDbType.VarChar, 50).Value = roomId;
                            cmd.Parameters.Add("@CheckInDate", SqlDbType.Date).Value = checkIn;
                            cmd.Parameters.Add("@CheckOutDate", SqlDbType.Date).Value = checkOut;
                            cmd.Parameters.Add("@Guests", SqlDbType.Int).Value = guests;
                            cmd.Parameters.Add("@Total", SqlDbType.Decimal).Value = total;
                            cmd.Parameters["@Total"].Precision = 12;
                            cmd.Parameters["@Total"].Scale = 2;
                            cmd.ExecuteNonQuery();
                        }

                        tx.Commit();
                        return bookingId;
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        public void CancelBooking(string bookingId, string customerId = null)
        {
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            {
                cn.Open();
                using (SqlTransaction tx = cn.BeginTransaction())
                {
                    try
                    {
                        string where = customerId == null
                            ? "BookingId=@BookingId"
                            : "BookingId=@BookingId AND CustomerId=@CustomerId";

                        using (SqlCommand cmd = new SqlCommand(
                            "UPDATE dbo.Bookings SET BookingStatus='Cancelled' WHERE " + where + ";", cn, tx))
                        {
                            cmd.Parameters.Add("@BookingId", SqlDbType.VarChar, 50).Value = bookingId;
                            if (customerId != null)
                                cmd.Parameters.Add("@CustomerId", SqlDbType.VarChar, 50).Value = customerId;
                            if (cmd.ExecuteNonQuery() == 0)
                                throw new Exception("Booking was not found.");
                        }

                        UpdateRoomAvailability(bookingId, cn, tx);
                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        public void UpdateStatus(string bookingId, string status)
        {
            if (status != "Booked" && status != "Checked-In" && status != "Checked-Out" && status != "Cancelled")
                throw new Exception("Invalid booking status.");

            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            {
                cn.Open();
                using (SqlTransaction tx = cn.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand cmd = new SqlCommand(
                            "UPDATE dbo.Bookings SET BookingStatus=@Status WHERE BookingId=@BookingId;", cn, tx))
                        {
                            cmd.Parameters.Add("@Status", SqlDbType.VarChar, 30).Value = status;
                            cmd.Parameters.Add("@BookingId", SqlDbType.VarChar, 50).Value = bookingId;
                            if (cmd.ExecuteNonQuery() == 0)
                                throw new Exception("Booking was not found.");
                        }

                        UpdateRoomAvailability(bookingId, cn, tx);
                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        private static void UpdateRoomAvailability(string bookingId, SqlConnection cn, SqlTransaction tx)
        {
            using (SqlCommand cmd = new SqlCommand(@"
                UPDATE r
                SET Status = CASE
                    WHEN EXISTS (
                        SELECT 1 FROM dbo.Bookings b2
                        WHERE b2.RoomId=r.RoomId
                          AND b2.BookingStatus IN ('Booked','Checked-In')
                    ) THEN 'Booked'
                    ELSE 'Available'
                END
                FROM dbo.Rooms r
                INNER JOIN dbo.Bookings b ON b.RoomId=r.RoomId
                WHERE b.BookingId=@BookingId;", cn, tx))
            {
                cmd.Parameters.Add("@BookingId", SqlDbType.VarChar, 50).Value = bookingId;
                cmd.ExecuteNonQuery();
            }
        }

        private static string CreateBookingId(SqlConnection cn, SqlTransaction tx)
        {
            string prefix = "BK" + DateTime.Now.ToString("yyyyMMddHHmmss");
            using (SqlCommand cmd = new SqlCommand(
                "SELECT COUNT(*) FROM dbo.Bookings WHERE BookingId LIKE @Prefix + '%';", cn, tx))
            {
                cmd.Parameters.Add("@Prefix", SqlDbType.VarChar, 30).Value = prefix;
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return prefix + (count + 1).ToString("D3");
            }
        }

        private static List<Booking> Query(string sql, string customerId)
        {
            List<Booking> list = new List<Booking>();
            using (SqlConnection cn = SqlDbDataAccess.GetConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (customerId != null)
                    cmd.Parameters.Add("@cid", SqlDbType.VarChar, 50).Value = customerId;
                cn.Open();
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Booking
                        {
                            BookingId = r.GetString(0),
                            CustomerId = r.GetString(1),
                            GuestName = r.GetString(2),
                            RoomId = r.GetString(3),
                            RoomNumber = r.GetString(4),
                            HotelId = r.GetString(5),
                            HotelName = r.GetString(6),
                            Location = r.GetString(7),
                            RoomType = r.GetString(8),
                            CheckInDate = r.GetDateTime(9),
                            CheckOutDate = r.GetDateTime(10),
                            Guests = r.GetInt32(11),
                            TotalAmount = r.GetDecimal(12),
                            BookingStatus = r.GetString(13),
                            PaymentStatus = r.GetString(14),
                            BookingDate = r.GetDateTime(15)
                        });
                    }
                }
            }
            return list;
        }
    }
}
