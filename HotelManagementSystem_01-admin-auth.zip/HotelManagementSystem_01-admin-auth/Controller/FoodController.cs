﻿using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDeliverySystem.Controller
{
    public class FoodController
    {
        public Foods food = new Foods();
        public void AddFood(Food food)
        {
            Foods fd = new Foods();
            fd.AddFood(food);
        }

        public bool UniqueFoodId(string foodId)
        {
            Foods foodData = new Foods();
            return foodData.UniqueFoodId(foodId);
        }

        public void DeleteFood(string foodId)
        {
            Foods foods = new Foods();
            foods.DeleteFood(foodId);
        }

        public void DeleteFoodId(string id)
        {
            Foods foods = new Foods();
            foods.DeleteFoodId(id);
        }

        public void UpdateFood(Food food)
        {
            Foods fd = new Foods();
            fd.UpdateFood(food);
        }

        public Food SearchFood(string foodId)
        {
            Foods fd = new Foods();
            Food f = fd.SearchFood(foodId);
            return f;
            
        }

        public List<Food> GetAllFood()
        {
            Foods f = new Foods();
            List<Food> GetAllFood = f.GetAllFood();
            return GetAllFood;
        }
        public List<Food> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Food> foodList = new List<Food>();

           
            return foodList;
       
        }

        public int ShowTotalFood()
        {
            FoodController fc = new FoodController();
            return fc.GetFoodCount();
        }

        public int GetFoodCount()
        {
            return food.GetFoodCount();
        }

        public bool DecreaseFoodQuantity(string foodId, int quantity)
        {
            Foods f = new Foods();
            return f.DecreaseFoodQuantity(foodId, quantity);
        }
    }
}
