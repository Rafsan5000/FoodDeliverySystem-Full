/* ================================================================
   HotelManagementDB - LocalDB / SQL Server
   C# WinForms Hotel Management System

   Server:   (localdb)\MSSQLLocalDB
   Database: HotelManagementDB

   Run this whole script in SSMS.
   NOTE: This script recreates the application tables and sample data.
   ================================================================ */

IF DB_ID(N'HotelManagementDB') IS NULL
    CREATE DATABASE HotelManagementDB;
GO

USE HotelManagementDB;
GO

/* Drop child/dependent tables first */
IF OBJECT_ID(N'dbo.Orders', N'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID(N'dbo.Food', N'U') IS NOT NULL DROP TABLE dbo.Food;
IF OBJECT_ID(N'dbo.Bookings', N'U') IS NOT NULL DROP TABLE dbo.Bookings;
IF OBJECT_ID(N'dbo.Rooms', N'U') IS NOT NULL DROP TABLE dbo.Rooms;
IF OBJECT_ID(N'dbo.Hotels', N'U') IS NOT NULL DROP TABLE dbo.Hotels;
IF OBJECT_ID(N'dbo.LogIn', N'U') IS NOT NULL DROP TABLE dbo.LogIn;
IF OBJECT_ID(N'dbo.Customer', N'U') IS NOT NULL DROP TABLE dbo.Customer;
IF OBJECT_ID(N'dbo.Employee', N'U') IS NOT NULL DROP TABLE dbo.Employee;
IF OBJECT_ID(N'dbo.Admin', N'U') IS NOT NULL DROP TABLE dbo.Admin;
GO

/* ================================================================
   1. ADMIN
   ================================================================ */
CREATE TABLE dbo.Admin
(
    AdminId VARCHAR(50) NOT NULL PRIMARY KEY,
    Password VARCHAR(100) NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Number VARCHAR(20) NOT NULL UNIQUE,
    Role VARCHAR(30) NOT NULL DEFAULT 'Manager'
        CHECK (Role IN ('SuperAdmin','Manager')),
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

/* ================================================================
   2. CUSTOMER
   ================================================================ */
CREATE TABLE dbo.Customer
(
    CustomerId VARCHAR(50) NOT NULL PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Password VARCHAR(100) NOT NULL,
    Email VARCHAR(120) NOT NULL UNIQUE,
    Gender VARCHAR(30) NOT NULL,
    Security VARCHAR(100) NOT NULL,
    Status VARCHAR(30) NOT NULL DEFAULT 'Active',
    Address VARCHAR(255) NOT NULL,
    Number VARCHAR(20) NOT NULL UNIQUE
);
GO

/* ================================================================
   3. EMPLOYEE
   ================================================================ */
CREATE TABLE dbo.Employee
(
    EmployeeId VARCHAR(50) NOT NULL PRIMARY KEY,
    Password VARCHAR(100) NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Number VARCHAR(20) NOT NULL UNIQUE,
    Salary INT NULL,
    Security VARCHAR(100) NOT NULL
);
GO

/* ================================================================
   4. LOGIN
   Used by normal Customer/Employee login screen.
   Admin login uses dbo.Admin directly.
   ================================================================ */
CREATE TABLE dbo.LogIn
(
    LogId VARCHAR(50) NOT NULL PRIMARY KEY,
    Password VARCHAR(100) NOT NULL,
    Security VARCHAR(100) NOT NULL,
    Role VARCHAR(30) NOT NULL CHECK (Role IN ('Customer','Employee'))
);
GO

/* ================================================================
   5. HOTELS
   One database can manage multiple hotels.
   ================================================================ */
CREATE TABLE dbo.Hotels
(
    HotelId VARCHAR(50) NOT NULL PRIMARY KEY,
    HotelName VARCHAR(120) NOT NULL,
    Location VARCHAR(255) NOT NULL,
    ContactNumber VARCHAR(30) NOT NULL,
    Description VARCHAR(500) NULL,
    ImagePath VARCHAR(255) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

/* ================================================================
   6. ROOMS
   ================================================================ */
CREATE TABLE dbo.Rooms
(
    RoomId VARCHAR(50) NOT NULL PRIMARY KEY,
    HotelId VARCHAR(50) NOT NULL,
    RoomNumber VARCHAR(30) NOT NULL,
    RoomType VARCHAR(50) NOT NULL,
    Capacity INT NOT NULL CHECK (Capacity > 0),
    PricePerNight DECIMAL(12,2) NOT NULL CHECK (PricePerNight >= 0),
    Description VARCHAR(500) NULL,
    ImagePath VARCHAR(255) NULL,
    Status VARCHAR(30) NOT NULL DEFAULT 'Available'
        CHECK (Status IN ('Available','Booked','Maintenance')),
    CONSTRAINT FK_Rooms_Hotels
        FOREIGN KEY (HotelId) REFERENCES dbo.Hotels(HotelId),
    CONSTRAINT UQ_Rooms_HotelRoom
        UNIQUE (HotelId, RoomNumber)
);
GO

/* ================================================================
   7. HOTEL BOOKINGS
   ================================================================ */
CREATE TABLE dbo.Bookings
(
    BookingId VARCHAR(50) NOT NULL PRIMARY KEY,
    CustomerId VARCHAR(50) NOT NULL,
    RoomId VARCHAR(50) NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    Guests INT NOT NULL CHECK (Guests > 0),
    TotalAmount DECIMAL(12,2) NOT NULL CHECK (TotalAmount >= 0),
    BookingStatus VARCHAR(30) NOT NULL DEFAULT 'Booked'
        CHECK (BookingStatus IN ('Booked','Checked-In','Checked-Out','Cancelled')),
    PaymentStatus VARCHAR(30) NOT NULL DEFAULT 'Pending'
        CHECK (PaymentStatus IN ('Pending','Paid','Refunded')),
    BookingDate DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT FK_Bookings_Customer
        FOREIGN KEY (CustomerId) REFERENCES dbo.Customer(CustomerId),
    CONSTRAINT FK_Bookings_Room
        FOREIGN KEY (RoomId) REFERENCES dbo.Rooms(RoomId),
    CONSTRAINT CK_Bookings_Dates
        CHECK (CheckOutDate > CheckInDate)
);
GO

/* ================================================================
   8. FOOD - retained so the original food screens do not break
   ================================================================ */
CREATE TABLE dbo.Food
(
    FoodId VARCHAR(50) NOT NULL PRIMARY KEY,
    FoodName VARCHAR(120) NOT NULL,
    Quantity FLOAT NOT NULL DEFAULT 0 CHECK (Quantity >= 0),
    Price FLOAT NOT NULL CHECK (Price >= 0),
    Description VARCHAR(500) NOT NULL,
    Id VARCHAR(50) NOT NULL,
    Image VARBINARY(MAX) NULL
);
GO

/* ================================================================
   9. ORDERS - retained so the original order/cart screens do not break
   ================================================================ */
CREATE TABLE dbo.Orders
(
    OrderId VARCHAR(50) NOT NULL PRIMARY KEY,
    CustomerId VARCHAR(50) NOT NULL,
    TotalPrice FLOAT NOT NULL CHECK (TotalPrice >= 0),
    Date DATETIME NOT NULL DEFAULT GETDATE(),
    ProductNames VARCHAR(1000) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    PaymentMethod VARCHAR(50) NOT NULL,
    PaymentStatus VARCHAR(50) NOT NULL
);
GO

/* ================================================================
   SAMPLE SUPER ADMINS + MANAGERS
   ================================================================ */
INSERT INTO dbo.Admin(AdminId,Password,Name,Number,Role) VALUES
('SA001','Admin@123','System Super Admin','01700000001','SuperAdmin'),
('SA002','Admin@456','Operations Super Admin','01700000002','SuperAdmin'),
('SA003','Admin@789','Security Super Admin','01700000004','SuperAdmin'),
('SA004','Admin@321','Finance Super Admin','01700000005','SuperAdmin'),
('MGR001','Manager@123','Hotel Manager','01700000003','Manager'),
('MGR002','Manager@456','Dhaka Hotel Manager','01700000006','Manager'),
('MGR003','Manager@789','Coxs Bazar Hotel Manager','01700000007','Manager'),
('MGR004','Manager@321','Sylhet Hotel Manager','01700000008','Manager');
GO

/* ================================================================
   SAMPLE CUSTOMER
   ================================================================ */
INSERT INTO dbo.Customer
(CustomerId,Name,Password,Email,Gender,Security,Status,Address,Number)
VALUES
('CUS001','Demo Guest','Customer@123','customer@example.com','Other',
 'blue','Active','Dhaka, Bangladesh','01800000001');
GO

/* ================================================================
   SAMPLE EMPLOYEES
   ================================================================ */
INSERT INTO dbo.Employee
(EmployeeId,Password,Name,Address,Number,Salary,Security)
VALUES
('EMP001','Employee@123','Demo Hotel Staff','Dhaka, Bangladesh','01900000001',25000,'blue'),
('EMP002','Employee@456','Rahim Ahmed','Dhaka, Bangladesh','01900000002',28000,'green'),
('EMP003','Employee@789','Karim Hasan','Dhaka, Bangladesh','01900000003',30000,'red'),
('EMP004','Employee@321','Nusrat Jahan','Coxs Bazar, Bangladesh','01900000004',27000,'blue'),
('EMP005','Employee@654','Sadia Akter','Coxs Bazar, Bangladesh','01900000005',29000,'yellow'),
('EMP006','Employee@987','Tanvir Hossain','Sylhet, Bangladesh','01900000006',26000,'green'),
('EMP007','Employee@111','Mehedi Hasan','Sylhet, Bangladesh','01900000007',31000,'red'),
('EMP008','Employee@222','Jannatul Ferdous','Dhaka, Bangladesh','01900000008',27500,'purple'),
('EMP009','Employee@333','Sakib Khan','Dhaka, Bangladesh','01900000009',32000,'orange'),
('EMP010','Employee@444','Ayesha Rahman','Coxs Bazar, Bangladesh','01900000010',28500,'pink');
GO

/* Normal login accounts for Customer + Employee */
INSERT INTO dbo.LogIn(LogId,Password,Security,Role) VALUES
('CUS001','Customer@123','blue','Customer'),
('EMP001','Employee@123','blue','Employee'),
('EMP002','Employee@456','green','Employee'),
('EMP003','Employee@789','red','Employee'),
('EMP004','Employee@321','blue','Employee'),
('EMP005','Employee@654','yellow','Employee'),
('EMP006','Employee@987','green','Employee'),
('EMP007','Employee@111','red','Employee'),
('EMP008','Employee@222','purple','Employee'),
('EMP009','Employee@333','orange','Employee'),
('EMP010','Employee@444','pink','Employee');
GO

/* ================================================================
   SAMPLE HOTELS
   ================================================================ */
INSERT INTO dbo.Hotels
(HotelId,HotelName,Location,ContactNumber,Description,ImagePath)
VALUES
('HTL001','Grand Palace Hotel','Dhaka, Bangladesh','02-55000001',
 'Comfortable rooms, modern facilities and professional service.','Pictures/background.png'),
('HTL002','Sea View Resort','Coxs Bazar, Bangladesh','0341-600001',
 'Relaxing rooms close to the beach with family-friendly facilities.','Pictures/background1.png'),
('HTL003','Green Valley Hotel','Sylhet, Bangladesh','0821-700001',
 'Quiet accommodation surrounded by the natural beauty of Sylhet.','Pictures/Add a subheading.png');
GO

/* ================================================================
   SAMPLE ROOMS
   ================================================================ */
INSERT INTO dbo.Rooms
(RoomId,HotelId,RoomNumber,RoomType,Capacity,PricePerNight,Description,ImagePath,Status)
VALUES
('RM001','HTL001','101','Single',1,2500,
 'Cozy single room','Pictures/Chicken-Biryani-Recipe.jpg','Available'),
('RM002','HTL001','102','Double',2,4000,
 'Comfortable double room','Pictures/Beef Steak.jpg','Available'),
('RM003','HTL001','201','Deluxe',3,6000,
 'Spacious deluxe room','Pictures/R.png','Available'),
('RM004','HTL002','301','Double',2,4500,
 'Sea-side double room','Pictures/download.jpeg','Available'),
('RM005','HTL002','302','Family',4,7000,
 'Large family room','Pictures/background1.png','Available'),
('RM006','HTL003','401','Deluxe',3,5500,
 'Deluxe room with modern facilities','Pictures/Untitled design.png','Available');
GO

/* ================================================================
   SAMPLE FOOD - keeps legacy food management functional
   ================================================================ */
INSERT INTO dbo.Food
(FoodId,FoodName,Quantity,Price,Description,Id,Image)
VALUES
('FD001','Chicken Biryani',25,220,'Traditional chicken biryani','EMP001',NULL),
('FD002','Beef Steak',15,650,'Grilled beef steak','EMP001',NULL),
('FD003','Cold Coffee',30,180,'Cafe-style cold coffee','EMP002',NULL);
GO

/* ================================================================
   VIEWS
   ================================================================ */
CREATE OR ALTER VIEW dbo.vw_BookingSummary AS
SELECT
    b.BookingId,
    b.CustomerId,
    c.Name AS GuestName,
    r.RoomId,
    r.RoomNumber,
    h.HotelId,
    h.HotelName,
    h.Location,
    r.RoomType,
    b.CheckInDate,
    b.CheckOutDate,
    b.Guests,
    b.TotalAmount,
    b.BookingStatus,
    b.PaymentStatus,
    b.BookingDate
FROM dbo.Bookings b
INNER JOIN dbo.Customer c ON c.CustomerId = b.CustomerId
INNER JOIN dbo.Rooms r ON r.RoomId = b.RoomId
INNER JOIN dbo.Hotels h ON h.HotelId = r.HotelId;
GO

CREATE OR ALTER VIEW dbo.vw_HotelDashboardStats AS
SELECT
    (SELECT COUNT(*) FROM dbo.Hotels WHERE IsActive=1) AS TotalHotels,
    (SELECT COUNT(*) FROM dbo.Rooms) AS TotalRooms,
    (SELECT COUNT(*) FROM dbo.Rooms WHERE Status='Available') AS AvailableRooms,
    (SELECT COUNT(*) FROM dbo.Customer) AS TotalGuests,
    (SELECT COUNT(*) FROM dbo.Employee) AS TotalEmployees,
    (SELECT COUNT(*) FROM dbo.Bookings) AS TotalBookings,
    (SELECT ISNULL(SUM(TotalAmount),0) FROM dbo.Bookings
        WHERE BookingStatus <> 'Cancelled') AS TotalRevenue;
GO

PRINT '=================================================';
PRINT 'HotelManagementDB is ready.';
PRINT 'Server: (localdb)\MSSQLLocalDB';
PRINT 'Database: HotelManagementDB';
PRINT 'Admin: SA001 / Admin@123';
PRINT 'Employee: EMP001 / Employee@123';
PRINT 'Customer: CUS001 / Customer@123';
PRINT '=================================================';
GO
