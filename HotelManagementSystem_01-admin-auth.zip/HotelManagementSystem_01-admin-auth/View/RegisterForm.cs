using System;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public partial class RegisterForm : Form
    {
        public RegisterForm() { InitializeComponent(); }

        private void Reg2Log_Click(object sender, EventArgs e)
        {
            Hide();
            new LogInForm().Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBox2.Text.Trim();
                string password = textBox3.Text;
                string confirmPassword = textBox4.Text;
                string email = textBox5.Text.Trim();
                string security = textBox6.Text.Trim();
                string address = textBox7.Text.Trim();
                string number = textBox8.Text.Trim();
                string gender = comboBox1.SelectedItem == null ? "Other" : comboBox1.SelectedItem.ToString();

                string role = null;
                if (radioButton1.Checked) role = radioButton1.Text;
                else if (radioButton2.Checked) role = radioButton2.Text;

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password) ||
                    string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(number))
                {
                    MessageBox.Show("Please fill in all required fields.", "Registration", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (password != confirmPassword)
                {
                    MessageBox.Show("Passwords do not match.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(role))
                {
                    MessageBox.Show("Please select Customer or Employee.");
                    return;
                }

                if (role == "Customer")
                {
                    CustomerController cc = new CustomerController();
                    string id = cc.GenerateNewCustomerId();
                    Customer customer = new Customer(id, name, password, email, gender, security,
                        "Active", address, number);
                    cc.AddCustomer(customer);
                    new LogInController().AddLogIn(new LogIn(id, password, security, "Customer"));

                    MessageBox.Show("Registration complete.\nYour Customer ID: " + id +
                                    "\nYour Password: " + password, "Registration Complete",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    EmployeeController ec = new EmployeeController();
                    string id = ec.GenerateNewEmployeeId();
                    Employee employee = new Employee(id, password, name, address, number, 0, security);
                    ec.AddEmployee(employee);
                    new LogInController().AddLogIn(new LogIn(id, password, security, "Employee"));

                    MessageBox.Show("Registration complete.\nYour Employee ID: " + id +
                                    "\nYour Password: " + password, "Registration Complete",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                Hide();
                new LogInForm().Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void RegisterForm_Load(object sender, EventArgs e) { }
    }
}
