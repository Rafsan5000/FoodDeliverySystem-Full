using System;
using System.Drawing;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public class EmployeeBookingForm : Form
    {
        private DataGridView grid;
        private ComboBox status;
        private Booking selected;

        public EmployeeBookingForm()
        {
            Text = "Booking Management";
            BackColor = Color.FromArgb(35, 35, 35);
            ForeColor = Color.White;
            Build();
            LoadData();
        }

        private void Build()
        {
            FlowLayoutPanel top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 55, Padding = new Padding(8) };
            status = new ComboBox { Width = 130, DropDownStyle = ComboBoxStyle.DropDownList };
            status.Items.AddRange(new object[] { "Booked", "Checked-In", "Checked-Out", "Cancelled" });
            status.SelectedIndex = 0;
            Button update = new Button { Text = "Update Status", AutoSize = true };
            Button refresh = new Button { Text = "Refresh", AutoSize = true };
            update.Click += (s, e) => UpdateStatus();
            refresh.Click += (s, e) => LoadData();
            top.Controls.Add(new Label { Text = "Status:", AutoSize = true, Margin = new Padding(5, 8, 2, 8) });
            top.Controls.Add(status);
            top.Controls.Add(update);
            top.Controls.Add(refresh);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
            grid.SelectionChanged += (s, e) => SelectBooking();
            Controls.Add(grid);
            Controls.Add(top);
        }

        private void LoadData()
        {
            try { grid.DataSource = new BookingController().GetAllBookings(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Database Error"); }
        }

        private void SelectBooking()
        {
            selected = grid.CurrentRow == null ? null : grid.CurrentRow.DataBoundItem as Booking;
            if (selected != null) status.SelectedItem = selected.BookingStatus;
        }

        private void UpdateStatus()
        {
            try
            {
                if (selected == null) { MessageBox.Show("Select a booking."); return; }
                new BookingController().UpdateStatus(selected.BookingId, status.Text);
                MessageBox.Show("Booking status updated.");
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Update Error"); }
        }
    }
}
