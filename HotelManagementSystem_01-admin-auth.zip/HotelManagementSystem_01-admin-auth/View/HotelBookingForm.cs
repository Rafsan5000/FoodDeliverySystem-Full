using System;
using System.Drawing;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public class HotelBookingForm : Form
    {
        private readonly Customer customer;
        private readonly RoomController roomController = new RoomController();
        private DataGridView grid;
        private DateTimePicker checkIn;
        private DateTimePicker checkOut;
        private NumericUpDown guests;
        private Label totalLabel;

        public HotelBookingForm(Customer customer)
        {
            this.customer = customer;
            Text = "Hotel Room Booking";
            BackColor = Color.FromArgb(35, 35, 35);
            ForeColor = Color.White;
            StartPosition = FormStartPosition.CenterParent;
            Build();
            LoadRooms();
        }

        private void Build()
        {
            FlowLayoutPanel top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 92,
                Padding = new Padding(10),
                WrapContents = true
            };

            checkIn = new DateTimePicker { Format = DateTimePickerFormat.Short, MinDate = DateTime.Today };
            checkOut = new DateTimePicker { Format = DateTimePickerFormat.Short, MinDate = DateTime.Today.AddDays(1) };
            guests = new NumericUpDown { Minimum = 1, Maximum = 20, Value = 1, Width = 55 };
            Button book = new Button { Text = "Book Selected Room", AutoSize = true };
            Button refresh = new Button { Text = "Refresh Rooms", AutoSize = true };
            totalLabel = new Label { Text = "Select a room to see price.", AutoSize = true, Margin = new Padding(10, 8, 0, 0) };

            checkIn.ValueChanged += (s, e) => ValidateDates();
            checkOut.ValueChanged += (s, e) => ValidateDates();
            guests.ValueChanged += (s, e) => UpdatePrice();
            book.Click += (s, e) => Book();
            refresh.Click += (s, e) => LoadRooms();
            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false
            };
            grid.SelectionChanged += (s, e) => UpdatePrice();

            AddField(top, "Check-in", checkIn);
            AddField(top, "Check-out", checkOut);
            AddField(top, "Guests", guests);
            top.Controls.Add(book);
            top.Controls.Add(refresh);
            top.Controls.Add(totalLabel);

            Controls.Add(grid);
            Controls.Add(top);
        }

        private static void AddField(FlowLayoutPanel p, string text, Control c)
        {
            p.Controls.Add(new Label { Text = text + ":", AutoSize = true, Margin = new Padding(8, 8, 2, 8) });
            p.Controls.Add(c);
        }

        private void LoadRooms()
        {
            try
            {
                grid.DataSource = roomController.GetAvailableRooms();
                UpdatePrice();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Database Error"); }
        }

        private void ValidateDates()
        {
            if (checkOut.Value.Date <= checkIn.Value.Date)
                checkOut.Value = checkIn.Value.Date.AddDays(1);
            UpdatePrice();
        }

        private void UpdatePrice()
        {
            Room room = grid == null || grid.CurrentRow == null
                ? null
                : grid.CurrentRow.DataBoundItem as Room;
            if (room == null)
            {
                totalLabel.Text = "Select a room to see price.";
                return;
            }
            int nights = Math.Max(1, (checkOut.Value.Date - checkIn.Value.Date).Days);
            totalLabel.Text = "Estimated total: " + (room.PricePerNight * nights).ToString("N2");
        }

        private void Book()
        {
            try
            {
                Room room = grid.CurrentRow == null ? null : grid.CurrentRow.DataBoundItem as Room;
                if (room == null) { MessageBox.Show("Select a room first."); return; }
                string id = new BookingController().CreateBooking(
                    customer.CustomerId, room.RoomId, checkIn.Value.Date,
                    checkOut.Value.Date, (int)guests.Value);
                MessageBox.Show("Booking confirmed.\nBooking ID: " + id, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadRooms();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Booking Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
