using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodDeliverySystem.View
{
   
    public partial class AdminDashBoard : Form
    {
       

        Admin admin;
        public AdminDashBoard(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
            // Extra control for the new multi-super-admin feature.
            if (admin != null && admin.IsSuperAdmin)
            {
                Button superAdminButton = new Button();
                superAdminButton.Name = "buttonSuperAdmin";
                superAdminButton.Text = "Super Admins";
                superAdminButton.Width = 120;
                superAdminButton.Height = 32;
                superAdminButton.Left = Math.Max(10, ClientSize.Width - 140);
                superAdminButton.Top = 12;
                superAdminButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                superAdminButton.Click += (sender, e) =>
                {
                    using (SuperAdminManager manager = new SuperAdminManager(this.admin))
                        manager.ShowDialog(this);
                };
                Controls.Add(superAdminButton);
                superAdminButton.BringToFront();
            }
             
        }

        public void LoadForm(Form Form)
        {

            panel2.Controls.Clear();
            Form.TopLevel = false;
            Form.Dock = DockStyle.Fill;
            panel2.Controls.Add(Form);
            Form.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadForm(new AdminCustomers());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadForm(new AdminEmployees());
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            HotelController h = new HotelController();
            CustomerController c = new CustomerController();
            EmployeeController ec = new EmployeeController();
            label2.Text = " Total Hotels : " + h.ShowTotalHotels();
            label3.Text = " Total Bookings : " + h.ShowTotalBookings();
            label4.Text = " Available Rooms : " + h.ShowAvailableRooms();
            label5.Text = " Total Employees : " + ec.ShowTotalEmployees();
        }

        public void ShowInfo()
        {
            HotelController h = new HotelController();
            CustomerController c = new CustomerController();
            EmployeeController e = new EmployeeController();
            panel2.Controls.Clear();
            label2.Text = " Total Hotels : " + h.ShowTotalHotels();
            label3.Text = " Total Bookings : " + h.ShowTotalBookings();
            label4.Text = " Available Rooms : " + h.ShowAvailableRooms();
            label5.Text = " Total Employees : "+e.ShowTotalEmployees();

            panel2.Controls.Add(label2);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label5);


        }
        private void AdminDashBoard_Load(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm lg = new LogInForm();
            lg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadForm(new HotelManagementForm(admin));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ShowInfo();
        }
    }
}
