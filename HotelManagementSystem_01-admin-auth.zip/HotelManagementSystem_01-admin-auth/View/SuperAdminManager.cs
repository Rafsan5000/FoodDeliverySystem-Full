using System;
using System.Drawing;
using System.Windows.Forms;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public class SuperAdminManager : Form
    {
        private readonly Admin currentAdmin;
        private DataGridView grid;
        private TextBox idBox,nameBox,numberBox,passwordBox;
        private ComboBox roleBox;

        public SuperAdminManager(Admin admin)
        {
            currentAdmin=admin;
            Text="Super Admin Control Center"; StartPosition=FormStartPosition.CenterParent;
            Size=new Size(920,610); MinimumSize=new Size(820,540); BackColor=Color.FromArgb(245,247,250);
            BuildUi(); LoadAdmins();
        }
        private Label MakeLabel(string text,int x,int y,int w=120){ return new Label{Text=text,Left=x,Top=y,Width=w,Font=new Font("Segoe UI",9,FontStyle.Bold),ForeColor=Color.FromArgb(55,65,81)}; }
        private void BuildUi()
        {
            var header=new Panel{Dock=DockStyle.Top,Height=78,BackColor=Color.FromArgb(31,41,55)};
            var title=new Label{Text="SUPER ADMIN • CONTROL CENTER",Left=24,Top=14,AutoSize=true,ForeColor=Color.White,Font=new Font("Segoe UI",17,FontStyle.Bold)};
            var sub=new Label{Text="Manage multiple administrator accounts and access status",Left=26,Top=46,AutoSize=true,ForeColor=Color.Gainsboro,Font=new Font("Segoe UI",9)};
            header.Controls.Add(title);header.Controls.Add(sub);Controls.Add(header);
            var panel=new Panel{Dock=DockStyle.Top,Height=160,Padding=new Padding(22)}; Controls.Add(panel);
            panel.Controls.Add(MakeLabel("Admin ID",22,12)); idBox=new TextBox{Left=22,Top=34,Width=165}; panel.Controls.Add(idBox);
            panel.Controls.Add(MakeLabel("Full Name",205,12)); nameBox=new TextBox{Left=205,Top=34,Width=190}; panel.Controls.Add(nameBox);
            panel.Controls.Add(MakeLabel("Phone",405,12)); numberBox=new TextBox{Left=405,Top=34,Width=160}; panel.Controls.Add(numberBox);
            panel.Controls.Add(MakeLabel("Password",575,12)); passwordBox=new TextBox{Left=575,Top=34,Width=150,UseSystemPasswordChar=true}; panel.Controls.Add(passwordBox);
            panel.Controls.Add(MakeLabel("Role",22,76)); roleBox=new ComboBox{Left=22,Top=98,Width=165,DropDownStyle=ComboBoxStyle.DropDownList}; roleBox.Items.AddRange(new object[]{"SuperAdmin","Manager"}); roleBox.SelectedIndex=0; panel.Controls.Add(roleBox);
            var add=new Button{Text="+ Add Admin",Left=205,Top=96,Width=140,Height=32}; add.Click+=Add_Click; panel.Controls.Add(add);
            var refresh=new Button{Text="Refresh",Left=355,Top=96,Width=100,Height=32}; refresh.Click+=(s,e)=>LoadAdmins(); panel.Controls.Add(refresh);
            var note=new Label{Text="Only Super Admin accounts should be used for system-wide administration.",Left=480,Top=103,AutoSize=true,ForeColor=Color.DimGray}; panel.Controls.Add(note);
            grid=new DataGridView{Dock=DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=Color.White,BorderStyle=BorderStyle.None,SelectionMode=DataGridViewSelectionMode.FullRowSelect,RowHeadersVisible=false};
            grid.CellDoubleClick+=Grid_CellDoubleClick; Controls.Add(grid);
            var footer=new Panel{Dock=DockStyle.Bottom,Height=52,BackColor=Color.White}; Controls.Add(footer);
            var close=new Button{Text="Close",Width=100,Height=30,Left=790,Top=10,Anchor=AnchorStyles.Right|AnchorStyles.Top}; close.Click+=(s,e)=>Close(); footer.Controls.Add(close);
        }
        private void LoadAdmins()
        {
            try { var list=new Admins().GetAllAdmins(); grid.DataSource=list; if(grid.Columns["Password"]!=null) grid.Columns["Password"].Visible=false; if(grid.Columns["IsSuperAdmin"]!=null) grid.Columns["IsSuperAdmin"].Visible=false; } catch(Exception ex){MessageBox.Show(ex.Message,"Database Error",MessageBoxButtons.OK,MessageBoxIcon.Error);}
        }
        private void Add_Click(object sender,EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(idBox.Text)||string.IsNullOrWhiteSpace(nameBox.Text)||string.IsNullOrWhiteSpace(numberBox.Text)||string.IsNullOrWhiteSpace(passwordBox.Text)){MessageBox.Show("Fill in all fields.");return;}
            try { new Admins().AddAdmin(new Admin{AdminId=idBox.Text, Password=passwordBox.Text, Name=nameBox.Text, Number=numberBox.Text, Role=roleBox.Text, IsActive=true}); } catch(Exception ex){MessageBox.Show(ex.Message,"Could not create admin",MessageBoxButtons.OK,MessageBoxIcon.Error);return;}
            MessageBox.Show("Administrator created successfully.","Success",MessageBoxButtons.OK,MessageBoxIcon.Information); idBox.Clear();nameBox.Clear();numberBox.Clear();passwordBox.Clear();LoadAdmins();
        }
        private void Grid_CellDoubleClick(object sender,DataGridViewCellEventArgs e)
        {
            if(e.RowIndex<0)return; string id=grid.Rows[e.RowIndex].Cells["AdminId"].Value.ToString();
            if(id==currentAdmin.AdminId){MessageBox.Show("You cannot deactivate your own account while logged in.");return;}
            bool active=Convert.ToBoolean(grid.Rows[e.RowIndex].Cells["IsActive"].Value);
            if(MessageBox.Show((active?"Deactivate ":"Activate ")+id+"?","Confirm",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes){new Admins().SetActive(id,!active);LoadAdmins();}
        }
    }
}
