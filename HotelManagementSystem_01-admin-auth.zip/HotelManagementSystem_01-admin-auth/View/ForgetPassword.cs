﻿using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodDeliverySystem.View
{
    public partial class ForgetPassword : Form
    {
        public ForgetPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string security = textBox1.Text;
                string newpass = textBox2.Text;
                string confirmpass = textBox3.Text;
                string id = textBox4.Text;

                if (newpass != confirmpass)
                {
                    MessageBox.Show("Passwords do not match.");
                    return;
                }

                CustomerController cc = new CustomerController();
                Customer c = cc.SearchCustomer(id);

                EmployeeController emc = new EmployeeController();
                Employee em = emc.SearchEmployee(id);

                LogInController lg = new LogInController();
                LogIn l = lg.SearchLogIn(id);

                if (l == null)
                {
                    MessageBox.Show("User Not Found");
                    return;
                }

                if (l.Role == "Customer")
                {
                

                    if (c.Security.Equals(security))
                    {
                        c.Password = newpass;
                        l.Password = newpass;

                        cc.UpdateCustomer(c);
                        lg.UpdateLogIn(l);

                        MessageBox.Show("Customer password updated successfully!");

                        this.Hide();
                        LogInForm lf = new LogInForm();
                        lf.Show();
                    }
                    else
                    {
                        MessageBox.Show("Security answer does not match.");
                    }
                }
                else if (l.Role == "Employee")
                {
                    

                    if (em.Security.Equals(security))
                    {
                        em.Password = newpass;
                        l.Password = newpass;

                        emc.UpdateByAmdin(em);
                        lg.UpdateLogIn(l);

                        MessageBox.Show("Employee password updated successfully!");

                        this.Hide();
                        LogInForm lf = new LogInForm();
                        lf.Show();
                    }
                    else
                    {
                        MessageBox.Show("Security answer does not match.");
                    }
                }
                else
                {
                    MessageBox.Show("Unknown role.");
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm lg = new LogInForm();
            lg.Show();
        }
    }
}
