﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public partial class AdminCustomers : Form
    {
        
        public AdminCustomers()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void AdminCustomers_Load(object sender, EventArgs e)
        {
            CustomerController cc = new CustomerController();
            dataGridView1.DataSource = cc.GetAllCustomer();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string customerID = textBox1.Text;
                CustomerController cc = new CustomerController();
                Customer c = cc.SearchCustomer(customerID);

                if (c != null)
                {
                    MessageBox.Show("Customer Found", "Information", MessageBoxButtons.OK);
                    textBox1.Text = c.CustomerId;
                    textBox2.Text = c.Name;
                    textBox7.Text = c.Password;
                    textBox3.Text = c.Email;
                    comboBox1.SelectedItem = c.Gender;
                    textBox6.Text = c.Security;
                    string status = c.Status;
                    textBox5.Text = c.Address;
                    textBox4.Text = c.Number;

                    if (c.Status == "Active")
                    {
                        radioButton1.Checked = true;
                    }
                    else if (c.Status == "Inactivte")
                    {
                        radioButton2.Checked = true;
                    }

                    textBox1.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Customer not Found", "Information", MessageBoxButtons.OK);
                }
                List<Customer> searchResult = new List<Customer> { c };
                dataGridView1.DataSource = searchResult;
                
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.StackTrace);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow dvr = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = dvr.Cells[0].Value.ToString();
                textBox2.Text = dvr.Cells[1].Value.ToString();
                textBox3.Text = dvr.Cells[2].Value.ToString();
                textBox7.Text = dvr.Cells[3].Value.ToString();
                comboBox1.SelectedItem = dvr.Cells[4].Value.ToString();
                textBox6.Text = dvr.Cells[5].Value.ToString();
                string status = dvr.Cells[6].Value.ToString();
                textBox5.Text = dvr.Cells[7].Value.ToString();
                textBox4.Text = dvr.Cells[8].Value.ToString();
  
                if (status == "Active")
                {
                    radioButton1.Checked = true;
                }
                else if (status == "Inactivte")
                {
                    radioButton2.Checked = true;
                }

                textBox1.Enabled = false;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string status = "";
                string customerId = textBox1.Text;
                string name = textBox2.Text;
                string password = textBox7.Text;
                string email = textBox3.Text;
                string gender = comboBox1.SelectedItem.ToString();
                string address = textBox5.Text;
                string security = textBox6.Text;
                string number = textBox4.Text;

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(gender) || comboBox1.SelectedItem == null ||
                    string.IsNullOrEmpty(customerId) ||
                    string.IsNullOrEmpty(security) ||
                    string.IsNullOrEmpty(address) ||
                    string.IsNullOrEmpty(number) ||
                    string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please fill in all fields!", "Information", MessageBoxButtons.OK);
                    return;
                }

                if (radioButton1.Checked)
                {
                    status = radioButton1.Text;
                }
                else if (radioButton2.Checked)
                {
                    status = radioButton2.Text;
                }
                else
                {
                    MessageBox.Show("Please select a role.", "Information", MessageBoxButtons.OK);
                }

                Customer c = new Customer(customerId, name, password, email, gender, security, status, address, number);
                CustomerController cc = new CustomerController();
                cc.UpdateCustomer(c);

                LogIn l = new LogIn(customerId, password, security, "Customer");
                LogInController lg = new LogInController();
                lg.UpdateLogIn(l);

                MessageBox.Show("Information Updated Succesfully", "Information", MessageBoxButtons.OK);
 
                dataGridView1.DataSource = cc.GetAllCustomer();
                dataGridView1.Refresh();

            }
            catch(Exception exp) 
            {
                MessageBox.Show(exp.StackTrace);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string customerId = textBox1.Text;


                CustomerController cc = new CustomerController();
                cc.DeleteCustomer(customerId);

                LogInController lg = new LogInController();
                lg.DeleteLogIn(customerId);

                MessageBox.Show("Customer Removed Succesfully");

                dataGridView1.DataSource = cc.GetAllCustomer();
                dataGridView1.Refresh();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.StackTrace, "Information",MessageBoxButtons.OK);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                comboBox1.Text = "";
                if (radioButton1.Checked)
                {
                    radioButton1.Checked = false;
                }
                else if (radioButton2.Checked)
                {
                    radioButton2.Checked = false;
                }

                CustomerController cc = new CustomerController();
                dataGridView1.DataSource = cc.GetAllCustomer();
                dataGridView1.Refresh();
                textBox1.Enabled = true;
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string id;
                string name = textBox2.Text;
                string email = textBox3.Text;
                string gender = comboBox1.SelectedItem.ToString();
                string security = textBox6.Text;
                string address = textBox5.Text;
                string number = textBox4.Text;
                string password = textBox7.Text;
                string role = "Customer";
                string status = "";
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(gender) || comboBox1.SelectedItem == null ||
                    string.IsNullOrEmpty(security) ||
                    string.IsNullOrEmpty(address) ||
                    string.IsNullOrEmpty(number) ||
                    string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please fill in all fields!");
                    return;
                }

                if (radioButton1.Checked)
                {
                    status = radioButton1.Text;
                }

                else if (radioButton2.Checked)
                {
                    status = radioButton2.Text;
                }

                else
                {
                    MessageBox.Show("Please select a Status.");
                    return;
                }

                CustomerController cc = new CustomerController();
                id = cc.GenerateNewCustomerId();

                Customer c = new Customer(id, name, password, email, gender, security, status, address, number);
                cc.AddCustomer(c);

                LogIn l = new LogIn(id, password, security, role);
                LogInController lc = new LogInController();
                lc.AddLogIn(l);

                MessageBox.Show("Your Customer Id: " + id + "\n" + "Your Password: " + password, "Registration Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dataGridView1.DataSource = cc.GetAllCustomer();
                dataGridView1.Refresh();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message, "Information", MessageBoxButtons.OK);
            }
        }
    }
}
