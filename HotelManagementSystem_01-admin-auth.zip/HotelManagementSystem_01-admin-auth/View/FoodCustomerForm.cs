﻿using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using static FoodDeliverySystem.View.FoodCustomerForm;
 

namespace FoodDeliverySystem.View
{
    public partial class FoodCustomerForm : Form
    {
        private int selectedRowIndex = -1;
        double selectedPrice;
        double totalPrice;
        double grandTotal = 0;
        private List<FoodOrder> foodOrders = new List<FoodOrder>();
        private string customerId;
        Customer customer;
        
        public FoodCustomerForm(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void FoodCustomerForm_Load_1(object sender, EventArgs e)
        {
            LoadFoodData();
        }

        private void LoadFoodData()
        {
            FoodController fc = new FoodController();
            var foodlist = fc.GetAllFood();

            DataTable filteredData = new DataTable();
            filteredData.Columns.Add("FoodName", typeof(string));
            filteredData.Columns.Add("Price", typeof(decimal));
            filteredData.Columns.Add("Description", typeof(string));
            filteredData.Columns.Add("Image", typeof(byte[]));
            filteredData.Columns.Add("FoodId", typeof(string));

            foreach (var food in foodlist)
            {
                filteredData.Rows.Add(food.FoodName, Convert.ToDecimal(food.Price), food.Description, food.Image, food.FoodId);
            }

            dataGridView1.DataSource = filteredData;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            if (dataGridView1.Columns["Image"] is DataGridViewImageColumn imgCol)
            {
                imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;
            }

            dataGridView1.ColumnHeadersVisible = true;
            dataGridView1.ReadOnly = true;
            dataGridView1.MultiSelect = false;
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.Columns["FoodId"].Visible = false;

            selectedRowIndex = -1;
            foodOrders.Clear();
            label2.Text = "";
            label3.Text = "";
            textBox3.Clear();
        }

        private void UpdateOrderAndTotals()
        {
            if (selectedRowIndex < 0 || comboBox1.SelectedItem == null) return;

            int quantity = int.Parse(comboBox1.SelectedItem.ToString());
            string selectedFoodId = dataGridView1.Rows[selectedRowIndex].Cells["FoodId"].Value.ToString();
            selectedPrice = Convert.ToDouble(dataGridView1.Rows[selectedRowIndex].Cells["Price"].Value);

            var existing = foodOrders.FirstOrDefault(f => f.FoodId == selectedFoodId);
            if (existing != null)
            {
                existing.Quantity = quantity;
                existing.UnitPrice = selectedPrice;
            }
            else
            {
                foodOrders.Add(new FoodOrder { FoodId = selectedFoodId, Quantity = quantity, UnitPrice = selectedPrice });
            }

            totalPrice = selectedPrice * quantity;
            label2.Text = "Selected Product price= " + totalPrice.ToString("C");

            grandTotal = foodOrders.Sum(item => item.UnitPrice * item.Quantity);
            label3.Text = "Total Price= " + grandTotal.ToString("C");
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= dataGridView1.Rows.Count) return;

            if (selectedRowIndex != -1)
            {
                dataGridView1.Rows[selectedRowIndex].Selected = false;
            }

            selectedRowIndex = e.RowIndex;
            dataGridView1.Rows[e.RowIndex].Selected = true;

            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["FoodName"].Value.ToString();

            string selectedFoodId = dataGridView1.Rows[e.RowIndex].Cells["FoodId"].Value.ToString();
            selectedPrice = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells["Price"].Value);

            var existing = foodOrders.FirstOrDefault(f => f.FoodId == selectedFoodId);
            if (existing != null)
            {
                comboBox1.SelectedItem = existing.Quantity.ToString();
            }
            else
            {
                comboBox1.SelectedItem = null;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!comboBox1.Focused) return;

            if (selectedRowIndex < 0)
            {
                MessageBox.Show("Please select a food item first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UpdateOrderAndTotals();
        }


        public class FoodOrder
        {
            public string FoodId { get; set; }
            public int Quantity { get; set; }
            public double UnitPrice { get; set; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FoodController fc = new FoodController();
            bool allUpdated = true;
            var foodList = fc.GetAllFood();

            foreach (var item in foodOrders) 
            {
                string foodId = item.FoodId;
                int quantity = item.Quantity;

                var foodItem = foodList.Find(f => f.FoodId == foodId);

                if (foodItem != null && foodItem.Quantity < quantity)
                {
                    allUpdated = false;
                    MessageBox.Show("Not enough stock for '{foodItem.FoodName}'. Available quantity: {foodItem.Quantity}","Stock Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    continue;
                }
                bool success = fc.DecreaseFoodQuantity(foodId, quantity);
                if (!success)
                {
                    allUpdated = false;
                    MessageBox.Show("Not enough stock for Food ID: {foodId}", "Database Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
 
            if (allUpdated)
            {
                OrderController orderController = new OrderController();
                int orderCount = orderController.GetOrderCount() + 1;
                string orderId = "ODR" + orderCount.ToString("D5");

                
                string productNames = string.Join(", ", foodOrders.Select(o =>
                {
                    var food = foodList.Find(f => f.FoodId == o.FoodId);
                    return $"{food?.FoodName} x{o.Quantity}";
                }));

                
                double grandTotal = 0;
                foreach (var o in foodOrders)
                {
                    var food = foodList.Find(f => f.FoodId == o.FoodId);
                    if (food != null)
                        grandTotal += food.Price * o.Quantity;
                }



                string address = customer.Address;
                DateTime date = DateTime.Now;
                customerId = customer.CustomerId;
                totalPrice = grandTotal;
                address = customer.Address;
                productNames = productNames;
                string paymentMethod = "Cash On";
                string paymentStatus = "Panding";

                Order order = new Order(orderId, customerId, totalPrice, date, productNames, address,paymentMethod,paymentStatus);
 
                orderController.AddOrder(order);
  
                MessageBox.Show("Order placed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
  
                Cart cart = new Cart(productNames, grandTotal, customer);
                CustomerDashBoard cs = new CustomerDashBoard(customer);
                cs.Hide();
                cart.Show();

                LoadFoodData();

                
            }
        }

    }
}
