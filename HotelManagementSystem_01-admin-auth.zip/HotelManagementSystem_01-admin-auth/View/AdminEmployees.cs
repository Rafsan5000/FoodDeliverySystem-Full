using System;
using System.Collections.Generic;
using System.Windows.Forms;
using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;

namespace FoodDeliverySystem.View
{
    public partial class AdminEmployees : Form
    {
        public AdminEmployees() { InitializeComponent(); }

        private void AdminEmployees_Load(object sender, EventArgs e) { RefreshGrid(); }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Employee employee = new EmployeeController().SearchEmployee(textBox1.Text.Trim());
                if (employee == null) { MessageBox.Show("Employee not found."); return; }
                FillForm(employee); textBox1.Enabled = false;
                dataGridView1.DataSource = new List<Employee> { employee };
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Employee employee = ReadForm(textBox1.Text.Trim());
                if (string.IsNullOrWhiteSpace(employee.EmployeeId)) { MessageBox.Show("Select an employee first."); return; }
                new EmployeeController().UpdateByAmdin(employee);
                new LogInController().UpdateLogIn(new LogIn(employee.EmployeeId, employee.Password, employee.Security, "Employee"));
                MessageBox.Show("Employee updated successfully."); RefreshGrid();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string id = textBox1.Text.Trim();
                if (string.IsNullOrWhiteSpace(id)) { MessageBox.Show("Select an employee first."); return; }
                if (MessageBox.Show("Delete employee " + id + "?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                new EmployeeController().DeleteEmployee(id);
                ClearForm(); RefreshGrid(); MessageBox.Show("Employee deleted successfully.");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            Employee employee = dataGridView1.Rows[e.RowIndex].DataBoundItem as Employee;
            if (employee != null) { FillForm(employee); textBox1.Enabled = false; }
        }

        private void button1_Click_1(object sender, EventArgs e) { ClearForm(); }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                EmployeeController controller = new EmployeeController();
                string id = controller.GenerateNewEmployeeId();
                Employee employee = ReadForm(id);
                if (string.IsNullOrWhiteSpace(employee.Name) || string.IsNullOrWhiteSpace(employee.Password) ||
                    string.IsNullOrWhiteSpace(employee.Number)) { MessageBox.Show("Name, password and number are required."); return; }
                controller.AddEmployee(employee);
                new LogInController().AddLogIn(new LogIn(id, employee.Password, employee.Security, "Employee"));
                MessageBox.Show("Employee added successfully.\nEmployee ID: " + id, "Success");
                ClearForm(); RefreshGrid();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private Employee ReadForm(string id)
        {
            int salary;
            if (!int.TryParse(textBox2.Text, out salary)) salary = 0;
            return new Employee(id, textBox7.Text.Trim(), textBox3.Text.Trim(), textBox5.Text.Trim(),
                textBox6.Text.Trim(), salary, textBox4.Text.Trim());
        }

        private void FillForm(Employee e)
        {
            textBox1.Text = e.EmployeeId; textBox2.Text = e.Salary.ToString(); textBox7.Text = e.Password;
            textBox3.Text = e.Name; textBox5.Text = e.Address; textBox6.Text = e.Number; textBox4.Text = e.Security;
        }

        private void ClearForm()
        {
            textBox1.Clear(); textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear(); textBox6.Clear(); textBox7.Clear();
            textBox1.Enabled = true;
        }

        private void RefreshGrid()
        {
            dataGridView1.DataSource = new EmployeeController().GetAllEmployee();
            dataGridView1.Refresh();
        }

        private void button1_Click(object sender, EventArgs e) { }
    }
}
