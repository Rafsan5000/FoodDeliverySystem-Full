using FoodDeliverySystem.Controller;
using FoodDeliverySystem.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodDeliverySystem.View
{
    public partial class FoodAdminForm : Form
    {
        private Image image;
        Admin admin;
        public FoodAdminForm(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
            selectedImageBytes = GetDefaultImageBytes();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public Byte[] selectedImageBytes;
        private byte[] GetDefaultImageBytes()
        {
            using (MemoryStream ms = new MemoryStream())
            {
                Properties.Resources._default.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
                selectedImageBytes = File.ReadAllBytes(ofd.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string foodId = textBox1.Text;
                string foodName = textBox2.Text;
                float quantity = float.Parse(textBox3.Text);
                float price = float.Parse(textBox4.Text);
                string description = textBox5.Text;
                string id = admin.AdminId;

                if (string.IsNullOrEmpty(foodId) || string.IsNullOrEmpty(foodName) || string.IsNullOrEmpty(description) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
                {
                    MessageBox.Show("Please Fill up All The Fields");
                    return;
                }

                Food food = new Food(foodId, foodName, quantity, price, description, id, selectedImageBytes);
                FoodController fc = new FoodController();

                if (fc.UniqueFoodId(foodId))
                {
                    MessageBox.Show("This Food ID already exists. Please enter a unique Food ID.");
                    return;
                }
                else
                {
                    fc.AddFood(food);
                    dataGridView1.DataSource = fc.GetAllFood();
                    dataGridView1.Refresh();
                }

                MessageBox.Show("Food added successfully.", "information", MessageBoxButtons.OK);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];


                textBox1.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                textBox3.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                textBox5.Text = row.Cells[4].Value.ToString();
                byte[] imageBytes = (byte[])row.Cells[6].Value;

                using (MemoryStream ms = new MemoryStream(imageBytes))
                {
                    pictureBox1.Image = Image.FromStream(ms);
                    selectedImageBytes = imageBytes;
                }

                textBox1.Enabled = false;

            }
        }

        private void FoodAdminForm_Load(object sender, EventArgs e)
        {
            FoodController fc = new FoodController();
            dataGridView1.DataSource = fc.GetAllFood();

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
            imgCol = (DataGridViewImageColumn)dataGridView1.Columns[6];
            imgCol.ImageLayout = DataGridViewImageCellLayout.Stretch;

            image = Properties.Resources._default;
            if (selectedImageBytes == null) selectedImageBytes = GetDefaultImageBytes();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string foodId = textBox1.Text;
                string foodName = textBox2.Text;
                float quantity = float.Parse(textBox3.Text);
                float price = float.Parse(textBox4.Text);
                string description = textBox5.Text;
                string id = admin.AdminId;

                if (string.IsNullOrEmpty(foodId) || string.IsNullOrEmpty(foodName) ||
                    string.IsNullOrEmpty(description) || string.IsNullOrEmpty(textBox3.Text) ||
                    string.IsNullOrEmpty(textBox4.Text))
                {
                    MessageBox.Show("Please fill in all fields.","Infromation",MessageBoxButtons.OK);
                    return;
                }


                Food food = new Food(foodId, foodName, quantity, price, description, id, selectedImageBytes);

                FoodController fc = new FoodController();
                fc.UpdateFood(food);

                dataGridView1.DataSource = fc.GetAllFood();
                dataGridView1.Refresh();

                textBox1.Enabled = false;

                MessageBox.Show("Food updated successfully.", "Infromation", MessageBoxButtons.OK);

            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox1.Enabled = true;
            selectedImageBytes = null;

            pictureBox1.Image = image;

            FoodController fc = new FoodController();
            dataGridView1.DataSource = fc.GetAllFood();
            dataGridView1.Refresh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string foodId = textBox1.Text;
                FoodController fc = new FoodController();
                Food f = fc.SearchFood(foodId);

                if (f != null)
                {
                    MessageBox.Show("Food Found", "Information", MessageBoxButtons.OK);
                    textBox1.Text = f.FoodId;
                    textBox2.Text = f.FoodName;
                    textBox3.Text = f.Quantity.ToString();
                    textBox4.Text = f.Price.ToString();
                    textBox5.Text = f.Description;
                    using (MemoryStream ms = new MemoryStream(f.Image))
                    {
                        pictureBox1.Image = Image.FromStream(ms);
                        selectedImageBytes = f.Image;
                    }

                    textBox1.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Food not Found", "Information", MessageBoxButtons.OK);
                }
                List<Food> searchResult = new List<Food> { f };
                dataGridView1.DataSource = searchResult;

            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string foodId = textBox1.Text;

                FoodController fc = new FoodController();
                fc.DeleteFood(foodId);

                MessageBox.Show("Food Removed Succesfully", "Information", MessageBoxButtons.OK);

                dataGridView1.DataSource = fc.GetAllFood();
                dataGridView1.Refresh();
            }

            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }
    }
}
