# GitHub Branch Package — Member 4 — Database, Food & Orders

**Suggested branch name:** `database-food-orders`

This ZIP is a complete snapshot of the current working project so Visual Studio can open/build it normally. All four members start from the same base project; each member should commit changes mainly to the files listed below, then push this work to the suggested branch.

## Assigned files
- `Model/SqlDbDataAccess.cs`
- `Controller/FoodController.cs`
- `Controller/OrderController.cs`
- `Model/Food.cs`
- `Model/Foods.cs`
- `Model/Order.cs`
- `Model/Orders.cs`
- `View/FoodAdminForm.cs`
- `View/FoodAdminForm.Designer.cs`
- `View/FoodAdminForm.resx`
- `View/FoodCustomerForm.cs`
- `View/FoodCustomerForm.Designer.cs`
- `View/FoodCustomerForm.resx`
- `View/FoodEmployeeForm.cs`
- `View/FoodEmployeeForm.Designer.cs`
- `View/FoodEmployeeForm.resx`
- `View/Cart.cs`
- `View/Cart.Designer.cs`
- `View/Cart.resx`
- `View/ConfirmOrder.cs`
- `View/ConfirmOrder.Designer.cs`
- `View/ConfirmOrder.resx`
- `Database_HotelManagementDB.sql`
- `Resources/food.png`

## Shared files
These remain available in every branch because the project must stay buildable:
- `App.config`
- `Program.cs`
- `FoodDeliverySystem.csproj`
- `FoodDeliverySystem.sln`
- `README.md`
- `Properties/AssemblyInfo.cs`
- `Properties/Resources.Designer.cs`
- `Properties/Resources.resx`
- `Properties/Settings.Designer.cs`
- `Properties/Settings.settings`
- `Pictures/` (shared image assets)

## GitHub workflow
1. Create/use the suggested branch from `main`.
2. Upload the contents of this project folder.
3. Make changes for this member's assigned module.
4. Commit with a meaningful message.
5. Push the branch and open a Pull Request into `main`.

**Important:** Do not delete the common files just to make the branches smaller. These packages are intentionally full project snapshots so each branch can be opened and tested independently.
