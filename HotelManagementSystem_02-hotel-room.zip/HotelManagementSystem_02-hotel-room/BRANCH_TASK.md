# GitHub Branch Package — Member 2 — Hotel & Room Management

**Suggested branch name:** `hotel-room-management`

This ZIP is a complete snapshot of the current working project so Visual Studio can open/build it normally. All four members start from the same base project; each member should commit changes mainly to the files listed below, then push this work to the suggested branch.

## Assigned files
- `Controller/HotelController.cs`
- `Controller/RoomController.cs`
- `Model/Hotel.cs`
- `Model/Room.cs`
- `View/HotelManagementForm.cs`
- `View/HotelBookingForm.cs`

## Shared files
These remain available in every branch because the project must stay buildable:
- `App.config`
- `Program.cs`
- `FoodDeliverySystem.csproj`
- `FoodDeliverySystem.sln`
- `README.md`
- `Properties/AssemblyInfo.cs`
- `Properties/Resources.Designer.cs`
- `Properties/Resources.resx`
- `Properties/Settings.Designer.cs`
- `Properties/Settings.settings`
- `Pictures/` (shared image assets)

## GitHub workflow
1. Create/use the suggested branch from `main`.
2. Upload the contents of this project folder.
3. Make changes for this member's assigned module.
4. Commit with a meaningful message.
5. Push the branch and open a Pull Request into `main`.

**Important:** Do not delete the common files just to make the branches smaller. These packages are intentionally full project snapshots so each branch can be opened and tested independently.
